public interface Cell {
    int x = 0;
    int y = 0;
    int getXPos = 0;
    int getYPos = 0;
    
    public int getX();
    
    public int getY();
    
    Player getPlayer();

	RoomType getType();
}
