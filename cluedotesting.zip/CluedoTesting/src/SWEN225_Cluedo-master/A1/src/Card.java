public interface Card {
    public String cardType = null;
    
    public String toString();

}
