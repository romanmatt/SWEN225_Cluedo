/**
 * Weapon Enum
 */
public enum WeaponType {
    CANDLESTICK {public String toString(){return "Candlestick";}},
    DAGGER      {public String toString(){return "Dagger";}},
    LEADPIPE    {public String toString(){return "Lead Pipe";}},
    REVOLVER    {public String toString(){return "Revolver";}},
    ROPE        {public String toString(){return "Rope";}},
    SPANNER     {public String toString(){return "Spanner";}},
}
